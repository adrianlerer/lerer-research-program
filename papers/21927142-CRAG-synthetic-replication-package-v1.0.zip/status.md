# Status

## Intended public archive

This frozen synthetic package accompanies the paper in Zenodo at DOI `10.5281/zenodo.21927142`. It includes the fixture, split designations, B0-B3 implementation, runner, tests, method and acceptance specifications, provenance and source inventories, machine-readable results, comparisons, report, and hashes. It excludes proprietary traces, reconstructed provider outputs, credentials, personal data, live exploit payloads, and vendor-endpoint probing code.

State: `COMPLETE_POLICY_CONFORMANCE_ONLY`

T1 matched its predeclared rule on 28 synthetic cases, including a 14-case
holdout of combined or transposed risk families. This establishes deterministic
conformance of the B3 implementation to the frozen contract. It does not
establish real-world effectiveness, model behavior, attack prevalence, or
production safety.
