import json
import unittest
from pathlib import Path

try:
    from research_artifacts.crag_benchmark import crag_b3, load_cases, run
except ModuleNotFoundError:  # Standalone Zenodo replication package.
    from crag_benchmark import crag_b3, load_cases, run


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CASES = HERE / "cases.jsonl"
if not CASES.exists():
    CASES = ROOT / "specs/paper-intake/reasoning-traces-runtime-admissibility/replication/cases.jsonl"


class CragBenchmarkTests(unittest.TestCase):
    def setUp(self):
        self.cases = load_cases(CASES)

    def test_fixture_has_frozen_development_and_holdout(self):
        self.assertEqual(len(self.cases), 28)
        self.assertEqual({c["split"] for c in self.cases}, {"development", "holdout"})
        self.assertEqual(len({c["id"] for c in self.cases}), 28)

    def test_crag_fails_closed_on_identity_and_integrity(self):
        selected = {c["id"]: c for c in self.cases}
        self.assertEqual(crag_b3(selected["dev-02"]), "DENY")
        self.assertEqual(crag_b3(selected["dev-03"]), "DENY")
        self.assertEqual(crag_b3(selected["hold-08"]), "DENY")

    def test_crag_preserves_benign_continuity(self):
        result = run(self.cases)["policies"]["B3"]
        self.assertEqual(result["splits"]["development"]["benign_continuity_preservation_rate"], 1.0)
        self.assertEqual(result["splits"]["holdout"]["benign_continuity_preservation_rate"], 1.0)

    def test_predeclared_acceptance_gate(self):
        result = run(self.cases)
        self.assertTrue(result["acceptance"]["pass"])
        self.assertEqual(result["policies"]["B3"]["overall"]["unsafe_automated_reliance_rate"], 0.0)

    def test_b3_improves_over_binding_only(self):
        result = run(self.cases)["policies"]
        self.assertLess(
            result["B3"]["overall"]["unsafe_automated_reliance_rate"],
            result["B2"]["overall"]["unsafe_automated_reliance_rate"],
        )


if __name__ == "__main__":
    unittest.main()
