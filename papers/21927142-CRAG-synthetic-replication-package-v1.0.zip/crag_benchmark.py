"""Deterministic policy-conformance benchmark for contextual runtime admissibility."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path


STATES = {"ALLOW", "CONSTRAIN", "QUARANTINE", "ESCALATE", "DENY"}
AUTOMATED = {"ALLOW", "CONSTRAIN"}


def baseline_b0(c):
    return "ALLOW" if c["syntactic"] else "DENY"


def baseline_b1(c):
    return "ALLOW" if c["syntactic"] and c["crypto"] else "DENY"


def baseline_b2(c):
    if not c["syntactic"] or not c["crypto"]:
        return "DENY"
    if not c["principal_match"] or not c["tenant_match"]:
        return "DENY"
    if (not c["session_match"] and not c["migration_attested"]) or not c["order_match"]:
        return "QUARANTINE"
    if not c["model_match"]:
        return "CONSTRAIN"
    return "ALLOW"


def crag_b3(c):
    bound = baseline_b2(c)
    if bound in {"DENY", "QUARANTINE"}:
        return bound
    if c["revoked"] or c["expired"]:
        return "DENY"
    if not c["purpose_match"]:
        return "ESCALATE"
    if c["contradicted"]:
        return "QUARANTINE"
    if c["instruction"] and (c["opaque"] or c["high_impact_tools"]):
        return "ESCALATE"
    if c["opaque"] and c["sensitive"] and c["high_impact_tools"]:
        return "ESCALATE"
    if c["opaque"] or not c["model_match"]:
        return "CONSTRAIN"
    return "ALLOW"


POLICIES = {"B0": baseline_b0, "B1": baseline_b1, "B2": baseline_b2, "B3": crag_b3}


def load_cases(path: Path):
    cases = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    ids = set()
    for c in cases:
        if c["id"] in ids:
            raise ValueError(f"duplicate id: {c['id']}")
        ids.add(c["id"])
        if c["gold"] not in STATES or not set(c["allowed"]).issubset(STATES):
            raise ValueError(f"invalid state in {c['id']}")
        if c["gold"] not in c["allowed"]:
            raise ValueError(f"gold not allowed in {c['id']}")
    return cases


def permits_unsafe_action(case, prediction):
    if prediction == "ALLOW":
        return not case["benign_continuity"]
    if prediction == "CONSTRAIN":
        return not case["constrain_safe"]
    return False


def metrics(rows):
    n = len(rows)
    unsafe_cases = [r for r in rows if not r["case"]["benign_continuity"]]
    benign_cases = [r for r in rows if r["case"]["benign_continuity"]]
    return {
        "n": n,
        "exact_accuracy": sum(r["prediction"] == r["case"]["gold"] for r in rows) / n,
        "acceptable_state_accuracy": sum(r["prediction"] in r["case"]["allowed"] for r in rows) / n,
        "unsafe_automated_reliance_rate": (
            sum(permits_unsafe_action(r["case"], r["prediction"]) for r in unsafe_cases) / len(unsafe_cases)
            if unsafe_cases else 0.0
        ),
        "benign_continuity_preservation_rate": (
            sum(r["prediction"] in AUTOMATED for r in benign_cases) / len(benign_cases)
            if benign_cases else 0.0
        ),
        "automated_coverage": sum(r["prediction"] in AUTOMATED for r in rows) / n,
        "escalation_rate": sum(r["prediction"] == "ESCALATE" for r in rows) / n,
    }


def run(cases):
    output = {"policies": {}, "case_count": len(cases)}
    for name, policy in POLICIES.items():
        rows = [{"case": c, "prediction": policy(c)} for c in cases]
        by_split = defaultdict(list)
        for row in rows:
            by_split[row["case"]["split"]].append(row)
        output["policies"][name] = {
            "overall": metrics(rows),
            "splits": {split: metrics(items) for split, items in sorted(by_split.items())},
            "predictions": [{"id": r["case"]["id"], "prediction": r["prediction"]} for r in rows],
        }
    b2 = output["policies"]["B2"]
    b3 = output["policies"]["B3"]
    split_pass = {}
    for split in ("development", "holdout"):
        m2, m3 = b2["splits"][split], b3["splits"][split]
        split_pass[split] = {
            "unsafe_zero": m3["unsafe_automated_reliance_rate"] == 0,
            "continuity_at_least_90": m3["benign_continuity_preservation_rate"] >= 0.90,
            "acceptable_at_least_90": m3["acceptable_state_accuracy"] >= 0.90,
            "strict_unsafe_improvement_over_b2": m3["unsafe_automated_reliance_rate"] < m2["unsafe_automated_reliance_rate"],
            "no_continuity_loss_vs_b2": m3["benign_continuity_preservation_rate"] >= m2["benign_continuity_preservation_rate"],
        }
    output["acceptance"] = {
        "splits": split_pass,
        "pass": all(all(v.values()) for v in split_pass.values()),
    }
    return output


def sha256(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    cases = load_cases(args.cases)
    result = run(cases)
    result["provenance"] = {
        "cases_path": str(args.cases),
        "cases_sha256": sha256(args.cases),
        "code_sha256": sha256(Path(__file__)),
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"out": str(args.out), "acceptance": result["acceptance"], "policies": {k: v["overall"] for k, v in result["policies"].items()}}, indent=2))


if __name__ == "__main__":
    main()
