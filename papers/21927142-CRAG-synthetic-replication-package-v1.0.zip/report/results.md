# CRAG Policy-Conformance Results

## Result

The predeclared gate passed on both the 14 development cases and 14 holdout
cases. B3 produced zero unsafe automated reliance, preserved all eight benign
continuity cases, and selected an allowed state in all 28 cases.

| Policy | Acceptable-state accuracy | Unsafe automated reliance | Benign continuity | Automated coverage |
| --- | ---: | ---: | ---: | ---: |
| B0 syntax only | 10.7% | 100% | 100% | 100% |
| B1 provenance | 14.3% | 95% | 100% | 96.4% |
| B2 binding | 46.4% | 60% | 100% | 71.4% |
| B3 full CRAG | 100% | 0% | 100% | 28.6% |

On holdout alone, B2 admitted 70% of unsafe cases automatically; B3 admitted
none. Both preserved 100% of benign continuity. B3 escalated 28.6% of holdout
cases and used non-automated states for the remainder of unsafe cases.

## What matched

T1 matched: within the frozen synthetic contract, adding semantic and
operational checks eliminated the unsafe admissions left by identity, tenant,
session, order and model binding without reducing benign continuity.

## What did not become evidence

The benchmark did not query an LLM, reproduce the source attack, measure
latency, estimate prevalence, or test adversarial adaptation. The gold labels
and B3 rules express the same theory, so 100% B3 accuracy shows implementation
fidelity. It is not independent validation of the theory. External expert
labeling, mutation testing, behavioral agent trials and real workflow shadow
evaluation remain necessary.
