# Zenodo File Manifest

This inventory defines the files accompanying the paper in the versioned Zenodo
replication deposit at DOI `10.5281/zenodo.21927142`.

| Deposited file | Verification role |
| --- | --- |
| `cases.jsonl` | Frozen 28-case synthetic fixture, including development and holdout designations, gold states, allowed states and rationales. |
| `crag_benchmark.py` | Executable B0-B3 policy implementation, metric computation and deterministic benchmark runner. |
| `test_crag_benchmark.py` | Unit tests and enforcement of the predeclared acceptance conditions. |
| `method_spec.md` | Hypotheses, tested scope, policy definitions, decision states, metrics, acceptance criteria and ethical limits. |
| `manifest.json` | Package identity and machine-readable map of the replication components. |
| `source_inventory.json` | Inventory distinguishing source-derived premises from synthetic benchmark evidence. |
| `reproduction_matrix.json` | Mapping from reported claims and tables to the files and commands that reproduce them. |
| `runs/latest.json` | Machine-readable case predictions, aggregate metrics, split metrics and acceptance result. |
| `comparisons/latest.json` | Nested B0-B3 policy comparison used to interpret the incremental contribution of each layer. |
| `provenance/latest.json` | Cryptographic hashes for the runner, fixture and result artifact. |
| `report/results.md` | Human-readable report supporting the figures stated in Section 7 and Table 1. |
| `task_ledger.md` | Execution ledger recording the completed replication tasks. |
| `status.md` | Completion state, limits and intended Zenodo archive boundary. |
| `ZENODO_FILE_MANIFEST.md` | This file-level inventory and verification map. |
| `README.md` | Minimal local reproduction instructions, scope and expected result. |
| `CITATION.cff` | Machine-readable citation metadata for the paper and package. |
| `LICENSE.txt` | Separate CC BY 4.0 terms for paper/data/documentation and MIT terms for code. |

## Exclusions

The deposit must not contain proprietary reasoning traces, reconstructed
provider outputs, credentials, personal data, live exploit payloads or code
that probes patched vendor endpoints. All benchmark identities, secrets,
instructions and tool consequences are synthetic.
