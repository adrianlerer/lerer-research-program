# CRAG Synthetic Policy-Conformance Benchmark

This package accompanies Ignacio Adrian Lerer's working paper, `Cryptographic
Validity Is Not Runtime Admissibility`, DOI `10.5281/zenodo.21927142`.

## Scope

The package reproduces a deterministic 28-case synthetic comparison of four
nested artifact-admission policies. It tests conformance to a frozen,
author-defined normative contract. It does not independently validate CRAG,
estimate production effectiveness, test adaptive adversaries or establish
evolutionary replication.

## Reproduce

From the package root, using Python 3.10 or later:

```text
python3 -m unittest test_crag_benchmark.py -v
python3 crag_benchmark.py --cases cases.jsonl --out reproduced-results.json
```

The expected aggregate comparison is recorded in `runs/latest.json` and
`report/results.md`. Use `provenance/latest.json` to verify the frozen source
artifacts. A newly generated result file can contain a different result-file
hash because the provenance receipt records its own generation context; the
case predictions and reported metrics must match.

## Safety boundary

All cases, identities, secrets, instructions and tool consequences are
synthetic. The package contains no proprietary reasoning traces, reconstructed
provider outputs, credentials, personal data, live exploit payloads or code
that probes vendor endpoints.
