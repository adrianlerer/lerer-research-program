#!/usr/bin/env python3
"""Reproduce numerical results for the AI liability burden-shift paper."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)


@dataclass(frozen=True)
class Params:
    k: float = 1.0
    p0: float = 1.0
    a: float = 1.0
    h: float = 100.0
    rho_max: float = 0.7
    rho_b: float = 2.0


P = Params()


def cost(x: float, p: Params = P) -> float:
    return p.k * x**2 / 2


def harm_prob(x: float, p: Params = P) -> float:
    return p.p0 * np.exp(-p.a * x)


def social_cost(x: float, p: Params = P) -> float:
    return cost(x, p) + harm_prob(x, p) * p.h


def rho_responsive(x: float, p: Params = P) -> float:
    return p.rho_max * x / (x + p.rho_b)


def rho_responsive_prime(x: float, p: Params = P) -> float:
    return p.rho_max * p.rho_b / (x + p.rho_b) ** 2


def solve_root(f, lo: float = 0.0, hi: float = 60.0) -> float:
    flo, fhi = f(lo), f(hi)
    if flo == 0:
        return lo
    if flo * fhi > 0:
        return golden_min(lambda z: abs(f(z)), lo, hi)
    for _ in range(240):
        mid = (lo + hi) / 2
        fm = f(mid)
        if abs(fm) < 1e-12 or (hi - lo) < 1e-12:
            return mid
        if flo * fm <= 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return (lo + hi) / 2


def golden_min(f, lo: float, hi: float, tol: float = 1e-12) -> float:
    gr = (np.sqrt(5) - 1) / 2
    c = hi - gr * (hi - lo)
    d = lo + gr * (hi - lo)
    fc, fd = f(c), f(d)
    while hi - lo > tol:
        if fc < fd:
            hi, d, fd = d, c, fc
            c = hi - gr * (hi - lo)
            fc = f(c)
        else:
            lo, c, fc = c, d, fd
            d = lo + gr * (hi - lo)
            fd = f(d)
    return float((lo + hi) / 2)


def x_full(h: float = P.h, p: Params = P) -> float:
    return solve_root(lambda x: p.k * x - p.a * p.p0 * h * np.exp(-p.a * x))


def x_claimant(sigma: float, h: float = P.h, p: Params = P) -> float:
    return solve_root(lambda x: p.k * x - p.a * p.p0 * sigma * h * np.exp(-p.a * x))


def x_presumption_constant(rho_bar: float, h: float = P.h, p: Params = P) -> float:
    return x_claimant(1 - rho_bar, h, p)


def x_presumption_responsive(h: float = P.h, p: Params = P) -> float:
    def foc(x):
        return p.k * x - p.h * np.exp(-p.a * x) * (
            p.a * (1 - rho_responsive(x, p)) + rho_responsive_prime(x, p)
        ) * (h / p.h)

    return solve_root(foc)


def negligence_threshold(x_star: float, p: Params = P) -> float:
    due = cost(x_star, p)

    def shirking_cost(sigma):
        x = golden_min(lambda z: cost(z, p) + sigma * harm_prob(z, p) * p.h, 0, x_star)
        return cost(x, p) + sigma * harm_prob(x, p) * p.h

    return solve_root(lambda s: shirking_cost(s) - due, 1e-12, 1.0)


def write_csv(path: Path, headers: list[str], rows: list[list[object]]) -> None:
    with path.open("w", encoding="utf-8") as f:
        f.write(",".join(headers) + "\n")
        for row in rows:
            f.write(",".join(str(x) for x in row) + "\n")


def baseline_table():
    xs = x_full()
    sc_star = social_cost(xs)
    rows = []
    cases = [
        ("First best", xs),
        ("Strict liability, claimant's burden", x_claimant(0.10)),
        ("Negligence, claimant's burden", x_claimant(0.10)),
        ("Presumption, care-insensitive rebuttal", x_presumption_constant(0.70)),
        ("Presumption, care-responsive rebuttal", x_presumption_responsive()),
    ]
    for label, x in cases:
        sc = social_cost(x)
        rows.append([label, f"{x:.3f}", f"{x / xs:.3f}", f"{sc:.3f}", f"{sc - sc_star:.3f}"])
    write_csv(OUT / "table_baseline.csv", ["Liability regime", "Care x", "x / x*", "Social cost", "Loss vs first best"], rows)
    return rows


def bilateral_table():
    def q(x, y):
        return np.exp(-x - y)

    def sc(x, y):
        return x**2 / 2 + y**2 / 2 + q(x, y) * P.h

    def solve_pair(foc_x, foc_y, guess=(1, 1)):
        z = np.array(guess, dtype=float)
        for _ in range(10000):
            x, y = z
            nx = solve_root(lambda xx: foc_x(xx, y), 0, 60)
            ny = solve_root(lambda yy: foc_y(nx, yy), 0, 60)
            nz = np.array([nx, ny])
            if np.linalg.norm(nz - z) < 1e-10:
                return float(nz[0]), float(nz[1])
            z = nz
        raise RuntimeError("No bilateral fixed point")

    joint_x = solve_root(lambda x: x - P.h * np.exp(-2 * x))
    joint_y = joint_x
    joint_sc = sc(joint_x, joint_y)

    full_x, full_y = x_full(), 0.0

    def claimant(sig):
        return solve_pair(
            lambda x, y: x - sig * P.h * np.exp(-x - y),
            lambda x, y: y - (1 - sig) * P.h * np.exp(-x - y),
            guess=(1, 2),
        )

    def presumption():
        return solve_pair(
            lambda x, y: x
            - P.h
            * np.exp(-x - y)
            * ((1 - rho_responsive(x)) + rho_responsive_prime(x)),
            lambda x, y: y - rho_responsive(x) * P.h * np.exp(-x - y),
            guess=(2, 1),
        )

    cases = [
        ("Joint optimum", joint_x, joint_y),
        ("Strict liability, full (sigma = 1)", full_x, full_y),
        ("Claimant's burden, sigma = 0.3", *claimant(0.3)),
        ("Claimant's burden, sigma = 0.1", *claimant(0.1)),
        ("Presumption, care-responsive", *presumption()),
    ]
    rows = []
    for label, x, y in cases:
        val = sc(x, y)
        rows.append([label, f"{x:.3f}", f"{y:.3f}", f"{val:.3f}", f"{val - joint_sc:.3f}"])
    write_csv(OUT / "table_bilateral_care.csv", ["Regime", "Developer x", "Victim y", "Social cost", "Loss vs optimum"], rows)
    return rows


def judgment_proof_table():
    xs = x_full()
    rows = []
    for assets in [100, 50, 20, 5]:
        xc = x_claimant(0.3, h=assets)
        xp = x_presumption_responsive(h=assets)
        rows.append([assets, f"{xc:.3f}", f"{xc / xs:.3f}", f"{xp:.3f}", f"{xp / xs:.3f}"])
    write_csv(OUT / "table_judgment_proof.csv", ["Developer assets A", "x, claimant's burden", "x / x*", "x, presumption", "x / x*"], rows)
    return rows


def activity_table():
    xs = x_full()
    unit_star = social_cost(xs)

    def benefit(n):
        return 60 * np.log1p(n)

    def scale_for_private_unit_cost(unit):
        return max(60 / unit - 1, 0)

    def welfare(x, n):
        return benefit(n) - n * social_cost(x)

    cases = [
        ("Social optimum", xs, scale_for_private_unit_cost(unit_star)),
        ("Strict liability, full (sigma = 1)", xs, scale_for_private_unit_cost(unit_star)),
    ]
    xc = x_claimant(0.3)
    private_c = cost(xc) + 0.3 * harm_prob(xc) * P.h
    cases.append(("Claimant's burden, sigma = 0.3", xc, scale_for_private_unit_cost(private_c)))
    xp = x_presumption_responsive()
    private_p = cost(xp) + harm_prob(xp) * (1 - rho_responsive(xp)) * P.h
    cases.append(("Presumption, care-responsive", xp, scale_for_private_unit_cost(private_p)))

    best = welfare(cases[0][1], cases[0][2])
    rows = []
    for label, x, n in cases:
        w = welfare(x, n)
        rows.append([label, f"{x:.3f}", f"{n:.3f}", f"{w:.3f}", f"{best - w:.3f}"])
    write_csv(OUT / "table_activity_levels.csv", ["Regime", "Care x", "Scale n", "Welfare", "Loss vs optimum"], rows)
    return rows


def figures():
    xs = x_full()
    sigmas = np.linspace(0.01, 1.0, 200)
    threshold = negligence_threshold(xs)
    claimant = np.array([x_claimant(s) for s in sigmas])
    negligence = np.where(sigmas >= threshold, xs, claimant)
    presumption = np.full_like(sigmas, x_presumption_responsive())

    draw_plot(
        OUT / "figure_1_equilibrium_care_vs_sigma.png",
        "Equilibrium care as probability of proof falls",
        "sigma",
        "x",
        [
            ("Claimant burden / strict liability", sigmas, claimant, (31, 119, 180)),
            ("Negligence", sigmas, negligence, (214, 39, 40)),
            ("Care-responsive presumption", sigmas, presumption, (44, 160, 44)),
        ],
        hlines=[("First best", xs)],
        vlines=[("Negligence threshold", threshold)],
    )

    def rho_sharp(x, m, t, rho_max=P.rho_max):
        return rho_max * x**t / (x**t + m**t)

    def rho_sharp_prime(x, m, t, rho_max=P.rho_max):
        return rho_max * t * (m**t) * (x ** (t - 1)) / (x**t + m**t) ** 2

    def solve_sharp(m, t):
        def foc(x):
            return x - P.h * np.exp(-x) * ((1 - rho_sharp(x, m, t)) + rho_sharp_prime(x, m, t))

        return solve_root(foc, 1e-8, 60)

    ts = np.linspace(0.15, 20, 120)
    series = []
    for m in [2.0, xs, 4.0]:
        values = [solve_sharp(m, t) for t in ts]
        label = f"m = {m:.3f}" if m == xs else f"m = {m:.1f}"
        color = (31, 119, 180) if m == 2.0 else (214, 39, 40) if m == xs else (44, 160, 44)
        series.append((label, ts, np.array(values), color))
    draw_plot(
        OUT / "figure_2_rebuttal_sharpness.png",
        "Equilibrium care as rebuttal standard sharpens",
        "sharpness t",
        "x",
        series,
        hlines=[("First best", xs)],
    )


def draw_plot(path: Path, title: str, xlabel: str, ylabel: str, series, hlines=None, vlines=None) -> None:
    width, height = 1100, 720
    left, right, top, bottom = 95, 60, 70, 90
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    plot_w = width - left - right
    plot_h = height - top - bottom
    all_x = np.concatenate([np.asarray(s[1], dtype=float) for s in series])
    all_y = np.concatenate([np.asarray(s[2], dtype=float) for s in series])
    if hlines:
        all_y = np.concatenate([all_y, np.array([v for _, v in hlines])])
    x_min, x_max = float(all_x.min()), float(all_x.max())
    y_min, y_max = float(all_y.min()), float(all_y.max())
    y_pad = (y_max - y_min) * 0.12 or 1.0
    y_min, y_max = max(0, y_min - y_pad), y_max + y_pad

    def xp(x):
        return left + (x - x_min) / (x_max - x_min) * plot_w

    def yp(y):
        return top + (y_max - y) / (y_max - y_min) * plot_h

    draw.rectangle([left, top, width - right, height - bottom], outline=(0, 0, 0), width=2)
    draw.text((left, 22), title, fill=(0, 0, 0))
    draw.text((left + plot_w / 2 - 30, height - 40), xlabel, fill=(0, 0, 0))
    draw.text((18, top + plot_h / 2 - 10), ylabel, fill=(0, 0, 0))

    for i in range(6):
        x = x_min + (x_max - x_min) * i / 5
        y = y_min + (y_max - y_min) * i / 5
        draw.line([(xp(x), height - bottom), (xp(x), height - bottom + 6)], fill=(0, 0, 0))
        draw.text((xp(x) - 18, height - bottom + 12), f"{x:.2g}", fill=(0, 0, 0))
        draw.line([(left - 6, yp(y)), (left, yp(y))], fill=(0, 0, 0))
        draw.text((35, yp(y) - 8), f"{y:.2g}", fill=(0, 0, 0))

    if hlines:
        for label, y in hlines:
            draw.line([(left, yp(y)), (width - right, yp(y))], fill=(80, 80, 80), width=1)
            draw.text((width - right - 150, yp(y) - 18), label, fill=(80, 80, 80))
    if vlines:
        for label, x in vlines:
            draw.line([(xp(x), top), (xp(x), height - bottom)], fill=(120, 120, 120), width=1)
            draw.text((xp(x) + 5, top + 5), label, fill=(80, 80, 80))

    for label, xs_, ys_, color in series:
        pts = [(xp(float(x)), yp(float(y))) for x, y in zip(xs_, ys_)]
        draw.line(pts, fill=color, width=4)

    lx, ly = left + 20, top + 20
    for label, _, _, color in series:
        draw.line([(lx, ly + 8), (lx + 38, ly + 8)], fill=color, width=4)
        draw.text((lx + 48, ly), label, fill=(0, 0, 0))
        ly += 24
    img.save(path)


def main() -> None:
    tables = [
        ("baseline", baseline_table()),
        ("bilateral_care", bilateral_table()),
        ("judgment_proof", judgment_proof_table()),
        ("activity_levels", activity_table()),
    ]
    figures()
    print("Generated outputs in", OUT)
    for name, rows in tables:
        print(f"\n{name}")
        for row in rows:
            print(" | ".join(map(str, row)))
    sigma = 0.30
    xp = x_presumption_responsive()
    print("\nchecks")
    print(f"x_star = {x_full():.6f}")
    print(f"negligence_threshold = {negligence_threshold(x_full()):.6f}")
    print(f"expected_recovery_claimant_sigma_{sigma:.2f} = {sigma * P.h:.2f}")
    print(f"expected_recovery_presumption = {(1 - rho_responsive(xp)) * P.h:.2f}")


if __name__ == "__main__":
    main()
