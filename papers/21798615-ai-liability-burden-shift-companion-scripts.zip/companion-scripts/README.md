# Companion scripts

These scripts reproduce the numerical tables and figures for:

Ignacio Adrian Lerer, "The Burden Shift Is Not Enough: Rebuttal Technology and Deterrence in Artificial Intelligence Liability" (working paper, 2026).

The implementation is reconstructed from the equations, parameter values, and reported numerical results in the paper. It is intended as a reproducibility companion for the corrected working-paper source. The activity-level benefit function is inferred from the reported scale equilibria as:

```text
B(n) = 60 log(1 + n)
```

Run:

```bash
python3 reproduce_ai_liability_burden_shift.py
```

Expected outputs:

- `outputs/table_baseline.csv`
- `outputs/table_bilateral_care.csv`
- `outputs/table_judgment_proof.csv`
- `outputs/table_activity_levels.csv`
- `outputs/figure_1_equilibrium_care_vs_sigma.png`
- `outputs/figure_2_rebuttal_sharpness.png`

The script is intentionally lightweight and depends only on NumPy and Pillow. It prints comparison checks against the paper's rounded values.
