#!/usr/bin/env python3
"""Create cross-run tables and a depth-profile figure from accepted run JSON."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt


def load_json(path: Path) -> Any:
    return json.loads(path.read_text())


def parse_run(spec: str) -> tuple[str, Path]:
    label, separator, path = spec.partition("=")
    if not separator:
        raise argparse.ArgumentTypeError("run must be LABEL=PATH")
    return label, Path(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="append", type=parse_run, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    rows: list[dict[str, Any]] = []
    primary_rows: list[dict[str, Any]] = []
    for label, run_dir in args.run:
        manifest = load_json(run_dir / "run-manifest.json")
        results = load_json(run_dir / "results.json")
        raw = load_json(run_dir / "raw-readouts.json")
        primary = results["primary_test"]["result"]
        primary_rows.append(
            {
                "label": label,
                "model": manifest["model"],
                "status": results["status"],
                "n_layers": manifest["n_layers"],
                "primary_layer": results["primary_test"]["layer"],
                "n_pairs": primary["n"],
                "mean_difference": primary["mean_difference"],
                "ci_low": primary["bootstrap_95_ci"][0],
                "ci_high": primary["bootstrap_95_ci"][1],
                "sign_flip_p": primary["two_sided_sign_flip_p"],
                "cohen_dz": primary["cohen_dz"],
                "affiliation_tokens_accepted": len(
                    raw["affiliation_inventory"]["accepted"]
                ),
                "affiliation_tokens_excluded": len(
                    raw["affiliation_inventory"]["excluded"]
                ),
                "control_tokens_accepted": len(raw["control_inventory"]["accepted"]),
                "surface_mean_difference": results["summaries"]["held_out"][
                    "surface_output"
                ]["mean_difference"],
            }
        )
        for layer, summary in results["summaries"]["held_out"]["layers"].items():
            rows.append(
                {
                    "label": label,
                    "model": manifest["model"],
                    "layer": int(layer),
                    "relative_depth": int(layer) / (manifest["n_layers"] - 1),
                    "mean_difference": summary["mean_difference"],
                    "ci_low": summary["bootstrap_95_ci"][0],
                    "ci_high": summary["bootstrap_95_ci"][1],
                    "sign_flip_p": summary["two_sided_sign_flip_p"],
                    "cohen_dz": summary["cohen_dz"],
                    "is_primary": int(layer) == results["primary_test"]["layer"],
                }
            )

    with (args.output_dir / "primary_results.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(primary_rows[0]))
        writer.writeheader()
        writer.writerows(primary_rows)
    with (args.output_dir / "layer_results.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (args.output_dir / "comparison.json").write_text(
        json.dumps({"primary": primary_rows, "layers": rows}, indent=2) + "\n"
    )

    figure, axis = plt.subplots(figsize=(7.2, 4.2))
    colors = ["#147d92", "#bd4f3c", "#6b5ca5", "#4f772d"]
    for color, (label, _) in zip(colors, args.run, strict=False):
        model_rows = sorted(
            (row for row in rows if row["label"] == label),
            key=lambda row: row["relative_depth"],
        )
        x = [row["relative_depth"] * 100 for row in model_rows]
        y = [row["mean_difference"] for row in model_rows]
        lower = [
            row["mean_difference"] - row["ci_low"] for row in model_rows
        ]
        upper = [
            row["ci_high"] - row["mean_difference"] for row in model_rows
        ]
        axis.errorbar(
            x,
            y,
            yerr=[lower, upper],
            marker="o",
            linewidth=1.8,
            capsize=3,
            label=label,
            color=color,
        )
    axis.axhline(0, color="#555555", linewidth=1, linestyle="--")
    axis.set_xlabel("Relative model depth (%)")
    axis.set_ylabel("Paired affiliation readout contrast (logit units)")
    axis.set_title("Held-out Jacobian-lens effects by model depth")
    axis.legend(frameon=False)
    axis.spines[["top", "right"]].set_visible(False)
    figure.tight_layout()
    figure.savefig(args.output_dir / "depth_profile.png", dpi=220)
    plt.close(figure)


if __name__ == "__main__":
    main()
