# SPAS Jacobian-lens pilot report

**Status:** `NOT_SUPPORTED_IN_PILOT`
**Model:** `HuggingFaceTB/SmolLM2-135M-Instruct`
**Primary layer:** `19`
**Held-out pairs:** `12`

## Primary result

Mean paired difference: `-0.1420` logit units.
Paired bootstrap 95% CI: `[-0.7587, 0.4846]`.
Two-sided sign-flip p-value: `0.6793`.
Cohen's dz: `-0.1228626939484662`.

## Token inventory

Accepted affiliation concepts: `9`.
Excluded multi-token affiliation concepts: `10`.
Accepted control concepts: `6`.

## Interpretation

The primary contrast measures whether affiliation-framed prompts make the model more disposed to verbalize affiliation concepts than matched neutral prompts. It does not measure human cognitive effects, consciousness, intent, or legal agency.

## Limitations

- One small open-weights model.
- The lens is fitted on a small generic corpus.
- Token inventory is restricted to single-token concepts.
- Prompt pairs add affiliation framing and therefore do not isolate every linguistic feature.
- No human outcome is measured; SPAS reception is not tested.
- This run is a local pilot, not an externally registered preregistration.
