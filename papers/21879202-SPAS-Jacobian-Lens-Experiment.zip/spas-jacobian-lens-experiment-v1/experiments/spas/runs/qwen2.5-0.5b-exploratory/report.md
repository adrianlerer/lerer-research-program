# SPAS Jacobian-lens pilot report

**Status:** `SUPPORTED_IN_PILOT`
**Model:** `Qwen/Qwen2.5-0.5B-Instruct`
**Primary layer:** `15`
**Held-out pairs:** `12`

## Primary result

Mean paired difference: `0.7197` logit units.
Paired bootstrap 95% CI: `[0.4230, 1.0248]`.
Two-sided sign-flip p-value: `0.0018`.
Cohen's dz: `1.2744187489679475`.

## Token inventory

Accepted affiliation concepts: `13`.
Excluded multi-token affiliation concepts: `6`.
Accepted control concepts: `12`.

## Interpretation

The primary contrast measures whether affiliation-framed prompts make the model more disposed to verbalize affiliation concepts than matched neutral prompts. It does not measure human cognitive effects, consciousness, intent, or legal agency.

## Limitations

- One small open-weights model.
- The lens is fitted on a small generic corpus.
- Token inventory is restricted to single-token concepts.
- Prompt pairs add affiliation framing and therefore do not isolate every linguistic feature.
- No human outcome is measured; SPAS reception is not tested.
- This run is a local pilot, not an externally registered preregistration.
