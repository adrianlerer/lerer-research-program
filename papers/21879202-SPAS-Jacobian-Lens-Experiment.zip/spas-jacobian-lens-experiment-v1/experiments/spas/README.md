# SPAS Jacobian-lens pilot

This experiment tests whether affiliation-framed prompts increase the model's
internal disposition to verbalize affiliation concepts before it produces an
answer. It is an extension of Lerer (2026), *Sub-Propositional Affiliation
Signals as Alignment Vectors*.

The pilot deliberately makes a narrow claim. A positive result is evidence
about the model's verbalizable internal representations. It is not evidence
that a human reader's kinship or affiliation modules were activated.

## Design

- Model: an open-weights causal decoder.
- Lens fitting corpus: generic text, disjoint from evaluation prompts.
- Evaluation: minimal pairs with the same substantive request and either an
  affiliation frame or a neutral frame.
- Primary layer: the fitted layer nearest 67% of model depth, fixed before
  looking at outcomes.
- Primary metric: affiliation-token mean logit minus neutral-control-token
  mean logit at the final input position.
- Primary contrast: paired affiliation-minus-neutral difference on the
  `held_out` split.
- Secondary analyses: all fitted layers, the `development` split, languages,
  and a surface-output affiliation proxy.

The experiment records every concept that is excluded because it is not a
single tokenizer token. Results must not be used to redefine the concept set.

## Run

```bash
uv run python -m experiments.spas.run all \
  --model HuggingFaceTB/SmolLM2-135M-Instruct \
  --output-dir experiments/spas/runs/smollm2-135m-pilot
```

Use `--device cpu` if MPS backward is unavailable. Fitting is resumable through
the checkpoint in the output directory.

## Outputs

- `lens.pt`: fitted Jacobian lens.
- `fit-checkpoint.pt`: resumable fitting state.
- `run-manifest.json`: model, environment, inputs, hashes, and fixed choices.
- `raw-readouts.json`: per-prompt, per-layer scores and generated responses.
- `results.json`: paired estimates, confidence intervals, and permutation tests.
- `report.md`: compact human-readable report.

## Interpretation gate

- `SUPPORTED_IN_PILOT`: held-out primary mean difference is positive and its
  95% paired bootstrap interval excludes zero.
- `NOT_SUPPORTED_IN_PILOT`: the interval includes zero or the mean is not
  positive.
- Neither state establishes a universal LLM mechanism or a human cognitive
  effect.
