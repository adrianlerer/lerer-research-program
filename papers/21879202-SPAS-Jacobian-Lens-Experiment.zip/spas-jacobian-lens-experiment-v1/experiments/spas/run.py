#!/usr/bin/env python3
"""Fit and evaluate a Jacobian-lens pilot for affiliation representations."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import random
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
import transformers

import jlens

HERE = Path(__file__).resolve().parent
DEFAULT_MODEL = "HuggingFaceTB/SmolLM2-135M-Instruct"
AFFILIATION_CONCEPTS = [
    " we", " us", " our", " together", " friend", " ally", " trust",
    " agree", " aligned", " nosotros", " juntos", " amigo", " aliado",
    " confianza", " acuerdo", " colega", " hermano", " compadre", " primo",
]
CONTROL_CONCEPTS = [
    " table", " number", " object", " process", " document", " list",
    " mesa", " numero", " objeto", " proceso", " documento", " lista",
]
SURFACE_TERMS = [
    "we", "us", "our", "together", "friend", "ally", "aligned", "agree",
    "nosotros", "juntos", "amigo", "aliado", "alineados", "colega",
    "hermano", "compadre", "primo",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text())


def choose_device(requested: str) -> str:
    if requested != "auto":
        return requested
    if torch.backends.mps.is_available():
        return "mps"
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"


def load_model(model_name: str, device: str):
    tokenizer = transformers.AutoTokenizer.from_pretrained(model_name)
    hf_model = transformers.AutoModelForCausalLM.from_pretrained(
        model_name, torch_dtype=torch.float32
    ).to(device)
    return hf_model, tokenizer, jlens.from_hf(hf_model, tokenizer)


def layer_selection(n_layers: int) -> list[int]:
    return sorted(
        {
            min(n_layers - 2, max(1, round((n_layers - 1) * fraction)))
            for fraction in (0.33, 0.50, 0.67, 0.80)
        }
    )


def single_token_inventory(tokenizer, concepts: list[str]) -> dict[str, Any]:
    accepted: list[dict[str, Any]] = []
    excluded: list[dict[str, Any]] = []
    for concept in concepts:
        ids = tokenizer(concept, add_special_tokens=False).input_ids
        entry = {"text": concept, "token_ids": ids}
        (accepted if len(ids) == 1 else excluded).append(entry)
    return {"accepted": accepted, "excluded": excluded}


def mean_token_logit(logits: torch.Tensor, token_ids: list[int]) -> float:
    if not token_ids:
        raise ValueError("concept inventory has no accepted single tokens")
    return float(logits[token_ids].float().mean().item())


def surface_rate(text: str) -> float:
    words = [word.strip(".,:;!?()[]{}\"'").lower() for word in text.split()]
    if not words:
        return 0.0
    return 100.0 * sum(word in SURFACE_TERMS for word in words) / len(words)


def paired_summary(values: list[float], seed: int) -> dict[str, Any]:
    array = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    boot = np.asarray([
        rng.choice(array, size=len(array), replace=True).mean() for _ in range(10000)
    ])
    observed = float(array.mean())
    signs = rng.choice(np.asarray([-1.0, 1.0]), size=(10000, len(array)))
    permuted = (signs * array).mean(axis=1)
    sd = float(array.std(ddof=1)) if len(array) > 1 else 0.0
    return {
        "n": len(values),
        "mean_difference": observed,
        "median_difference": float(np.median(array)),
        "sd_difference": sd,
        "cohen_dz": observed / sd if sd else None,
        "bootstrap_95_ci": [float(np.quantile(boot, 0.025)), float(np.quantile(boot, 0.975))],
        "two_sided_sign_flip_p": float((np.abs(permuted) >= abs(observed)).mean()),
        "differences": values,
    }


def git_commit() -> str | None:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=HERE, text=True
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def fit_lens(args: argparse.Namespace) -> None:
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = choose_device(args.device)
    hf_model, tokenizer, model = load_model(args.model, device)
    n_layers = model.n_layers
    layers = layer_selection(n_layers)
    prompts = load_json(Path(args.fit_corpus))
    started = utc_now()
    lens = jlens.fit(
        model,
        prompts=prompts,
        source_layers=layers,
        dim_batch=args.dim_batch,
        max_seq_len=args.max_seq_len,
        skip_first=args.skip_first,
        checkpoint_path=str(output_dir / "fit-checkpoint.pt"),
        checkpoint_every=1,
        resume=True,
    )
    lens.save(str(output_dir / "lens.pt"))
    manifest = {
        "started_at": started,
        "completed_at": utc_now(),
        "model": args.model,
        "device": device,
        "dtype": "float32",
        "n_layers": n_layers,
        "d_model": model.d_model,
        "source_layers": layers,
        "primary_layer": min(
            layers, key=lambda layer: abs(layer - 0.67 * (n_layers - 1))
        ),
        "n_fit_prompts": len(prompts),
        "dim_batch": args.dim_batch,
        "max_seq_len": args.max_seq_len,
        "skip_first": args.skip_first,
        "seed": args.seed,
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "git_commit": git_commit(),
        "inputs": {
            "fit_corpus": {"path": str(Path(args.fit_corpus)), "sha256": sha256(Path(args.fit_corpus))},
            "prompt_pairs": {"path": str(Path(args.prompt_pairs)), "sha256": sha256(Path(args.prompt_pairs))},
        },
        "lens_sha256": sha256(output_dir / "lens.pt"),
    }
    json_dump(output_dir / "run-manifest.json", manifest)
    del model, tokenizer, hf_model, lens


def generate(hf_model, tokenizer, prompt: str, max_new_tokens: int) -> str:
    if getattr(tokenizer, "chat_template", None):
        rendered = tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}],
            tokenize=False,
            add_generation_prompt=True,
        )
    else:
        rendered = prompt
    encoded = tokenizer(rendered, return_tensors="pt").to(hf_model.device)
    with torch.no_grad():
        output = hf_model.generate(
            **encoded,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )
    return tokenizer.decode(output[0, encoded.input_ids.shape[1]:], skip_special_tokens=True)


def evaluate(args: argparse.Namespace) -> None:
    output_dir = Path(args.output_dir)
    manifest = load_json(output_dir / "run-manifest.json")
    device = choose_device(args.device)
    hf_model, tokenizer, model = load_model(args.model, device)
    lens = jlens.JacobianLens.load(str(output_dir / "lens.pt"))
    pairs = load_json(Path(args.prompt_pairs))
    affiliation_inventory = single_token_inventory(tokenizer, AFFILIATION_CONCEPTS)
    control_inventory = single_token_inventory(tokenizer, CONTROL_CONCEPTS)
    affiliation_ids = [item["token_ids"][0] for item in affiliation_inventory["accepted"]]
    control_ids = [item["token_ids"][0] for item in control_inventory["accepted"]]
    rows: list[dict[str, Any]] = []
    for pair in pairs:
        condition_rows: dict[str, Any] = {}
        for condition in ("neutral", "affiliation"):
            prompt = pair[condition]
            lens_logits, model_logits, _ = lens.apply(
                model, prompt, layers=lens.source_layers, positions=[-1]
            )
            scores = {}
            for layer, logits in lens_logits.items():
                vector = logits[0]
                aff = mean_token_logit(vector, affiliation_ids)
                control = mean_token_logit(vector, control_ids)
                scores[str(layer)] = {
                    "affiliation_mean_logit": aff,
                    "control_mean_logit": control,
                    "contrast": aff - control,
                }
            final = model_logits[0]
            response = generate(hf_model, tokenizer, prompt, args.max_new_tokens)
            condition_rows[condition] = {
                "scores": scores,
                "final_layer_contrast": mean_token_logit(final, affiliation_ids) - mean_token_logit(final, control_ids),
                "response": response,
                "surface_affiliation_terms_per_100_words": surface_rate(response),
            }
        rows.append({
            "id": pair["id"],
            "language": pair["language"],
            "split": pair["split"],
            "neutral": condition_rows["neutral"],
            "affiliation": condition_rows["affiliation"],
        })
    raw = {
        "completed_at": utc_now(),
        "affiliation_inventory": affiliation_inventory,
        "control_inventory": control_inventory,
        "rows": rows,
    }
    json_dump(output_dir / "raw-readouts.json", raw)
    summaries: dict[str, Any] = {}
    for split in ("development", "held_out"):
        summaries[split] = {"layers": {}}
        split_rows = [row for row in rows if row["split"] == split]
        for layer in lens.source_layers:
            differences = [
                row["affiliation"]["scores"][str(layer)]["contrast"]
                - row["neutral"]["scores"][str(layer)]["contrast"]
                for row in split_rows
            ]
            summaries[split]["layers"][str(layer)] = paired_summary(differences, args.seed + layer)
        surface_differences = [
            row["affiliation"]["surface_affiliation_terms_per_100_words"]
            - row["neutral"]["surface_affiliation_terms_per_100_words"]
            for row in split_rows
        ]
        summaries[split]["surface_output"] = paired_summary(surface_differences, args.seed + 1000)
    primary = summaries["held_out"]["layers"][str(manifest["primary_layer"])]
    lo, hi = primary["bootstrap_95_ci"]
    status = "SUPPORTED_IN_PILOT" if primary["mean_difference"] > 0 and lo > 0 else "NOT_SUPPORTED_IN_PILOT"
    results = {
        "status": status,
        "primary_test": {
            "split": "held_out",
            "layer": manifest["primary_layer"],
            "decision_rule": "positive mean and paired bootstrap 95% CI entirely above zero",
            "result": primary,
        },
        "summaries": summaries,
        "limitations": [
            "One small open-weights model.",
            "The lens is fitted on a small generic corpus.",
            "Token inventory is restricted to single-token concepts.",
            "Prompt pairs add affiliation framing and therefore do not isolate every linguistic feature.",
            "No human outcome is measured; SPAS reception is not tested.",
            "This run is a local pilot, not an externally registered preregistration.",
        ],
    }
    json_dump(output_dir / "results.json", results)
    write_report(output_dir / "report.md", manifest, raw, results)


def write_report(path: Path, manifest: dict[str, Any], raw: dict[str, Any], results: dict[str, Any]) -> None:
    primary = results["primary_test"]["result"]
    lines = [
        "# SPAS Jacobian-lens pilot report",
        "",
        f"**Status:** `{results['status']}`",
        f"**Model:** `{manifest['model']}`",
        f"**Primary layer:** `{results['primary_test']['layer']}`",
        f"**Held-out pairs:** `{primary['n']}`",
        "",
        "## Primary result",
        "",
        f"Mean paired difference: `{primary['mean_difference']:.4f}` logit units.",
        f"Paired bootstrap 95% CI: `[{primary['bootstrap_95_ci'][0]:.4f}, {primary['bootstrap_95_ci'][1]:.4f}]`.",
        f"Two-sided sign-flip p-value: `{primary['two_sided_sign_flip_p']:.4f}`.",
        f"Cohen's dz: `{primary['cohen_dz'] if primary['cohen_dz'] is not None else 'undefined'}`.",
        "",
        "## Token inventory",
        "",
        f"Accepted affiliation concepts: `{len(raw['affiliation_inventory']['accepted'])}`.",
        f"Excluded multi-token affiliation concepts: `{len(raw['affiliation_inventory']['excluded'])}`.",
        f"Accepted control concepts: `{len(raw['control_inventory']['accepted'])}`.",
        "",
        "## Interpretation",
        "",
        "The primary contrast measures whether affiliation-framed prompts make the model more disposed to verbalize affiliation concepts than matched neutral prompts. It does not measure human cognitive effects, consciousness, intent, or legal agency.",
        "",
        "## Limitations",
        "",
        *[f"- {item}" for item in results["limitations"]],
    ]
    path.write_text("\n".join(lines) + "\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("fit", "evaluate", "all"))
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--device", choices=("auto", "mps", "cuda", "cpu"), default="auto")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--fit-corpus", default=str(HERE / "fit_corpus.json"))
    parser.add_argument("--prompt-pairs", default=str(HERE / "prompt_pairs.json"))
    parser.add_argument("--dim-batch", type=int, default=2)
    parser.add_argument("--max-seq-len", type=int, default=64)
    parser.add_argument("--skip-first", type=int, default=4)
    parser.add_argument("--max-new-tokens", type=int, default=48)
    parser.add_argument("--seed", type=int, default=20260810)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    if args.command in ("fit", "all"):
        fit_lens(args)
    if args.command in ("evaluate", "all"):
        evaluate(args)


if __name__ == "__main__":
    main()
