# DarwinX EPT/EGT Pilot

## Problem

DarwinX reports that population selection over agent harnesses can improve a
frozen model. The local satellite mesh already preserves lineages, requires
evidence before adoption, and prevents blind cross-vertical propagation. The
open question is whether an EPT/EGT-inspired selection rule improves outcomes
relative to a single lineage and a capability-only population rule.

## Goal

Run a reproducible, no-new-spend pilot comparing three policies under the same
candidate stream and evaluation budget:

1. `single_lineage`: greedy keep-best selection.
2. `population`: archive, bounded regression and recombination.
3. `ept_egt_multilevel`: individual, vertical and ecosystem fitness with
   governed horizontal adoption.

## Hypotheses frozen before execution

- H1: `ept_egt_multilevel` will produce greater held-out ecosystem coverage
  than `single_lineage`.
- H2: `ept_egt_multilevel` will produce fewer protected-capability regressions
  than capability-only `population` selection.
- H3: the EPT/EGT advantage, if any, will be largest when mutations are
  complementary across verticals and smallest when tasks are homogeneous.
- H4: `ept_egt_multilevel` may cost more evaluations per accepted improvement;
  cost per accepted held-out capability must therefore be reported.

## EPT/EGT operationalization

- Extended phenotype: observable capability produced by model plus prompts,
  skills, memory, tools and control flow.
- Individual level: each harness must add measured capability without crossing
  a protected-regression or compliance gate.
- Vertical level: specialists compete within a task ecology and retain
  distinct useful adaptations.
- Ecosystem level: selection rewards complementary coverage, transfer and
  preservation across the satellite population.
- Horizontal transmission: a mutation discovered in one vertical may be
  adopted elsewhere only after a receiver-specific compatibility check.

## Non-goals

- No model-weight training.
- No production self-modification.
- No private or client data.
- No claim that a deterministic simulation reproduces DarwinX's benchmark
  scores or proves EPT/EGT.
- No paid inference without a separate approved phase.

## Acceptance criteria

- Identical seeds, candidate streams and evaluation ceilings across policies.
- Training and held-out measurements remain separate.
- Protected capabilities and compliance are non-compensable gates.
- Raw per-seed results and aggregate metrics are retained.
- Null results and regressions appear in the paper.
- A later live-agent phase remains blocked until this mechanism pilot produces
  a stable signal and a fixed public/synthetic task suite is approved.

