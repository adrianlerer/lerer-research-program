# Technical Design

## Compose

The pilot uses a deterministic synthetic landscape so selection mechanics can
be tested without model calls. Each seed creates the same candidate mutations
for all three policies. Capabilities belong to four verticals and are divided
into training and held-out sets. Some mutations are local specialists, some
transfer across verticals, and some improve visible performance while damaging
protected behavior.

## Design

The simulator is `script/run_darwinx_ept_egt_pilot.py`.

- A state contains accepted mutations, per-capability values, protected
  capability values, compliance, and evaluation cost.
- `single_lineage` accepts a mutation only when scalar training fitness rises.
- `population` retains bounded-regression variants and periodically recombines
  complementary archive members.
- `ept_egt_multilevel` applies three gates: individual preservation, vertical
  contribution, and ecosystem complementarity. Cross-vertical effects count
  only after receiver compatibility succeeds.
- The held-out set is never used for promotion.

## Metrics

- training coverage;
- held-out coverage;
- protected regression count;
- compliance failures accepted;
- retained lineage diversity;
- evaluation cost;
- cost per held-out capability above baseline.

## Evidence boundary

This phase tests the selection rule on controlled landscapes. It does not test
LLM reasoning, prompt generation, verifier quality, benchmark contamination or
production transfer. A positive result authorizes only a second, preregistered
pilot on public or synthetic agent tasks.

## Verification

```bash
python3 script/run_darwinx_ept_egt_pilot.py \
  --output specs/darwinx-ept-egt-pilot/results.json
python3 -m unittest tests/darwinx_ept_egt/test_pilot.py
```

