THE AGENT HARNESS AS EXTENDED PHENOTYPE
Reproducibility package

Author: Ignacio Adrián Lerer
ORCID: 0009-0007-6378-9749

Contents

run_darwinx_ept_egt_pilot.py
Deterministic Python simulator.

test_pilot.py
Unit tests for reproducibility, held-out separation, and protected gates.

product.md
Problem, hypotheses frozen before execution, non-goals, and acceptance criteria.

tech.md and method_spec.md
Technical design and method specification.

results.json
Aggregate and raw per-seed results from the original execution.

results-rerun-2026-08-29.json
Independent local rerun. Its SHA-256 is identical to results.json:
01f8c864caffecdb173488c30ec44a550d45f50d09df94839d7c606b8168c8d5

manifest.json, source_inventory.json, and provenance/result.json
Source identity, boundaries, and provenance records.

Reproduction

From the repository root:

python3 script/run_darwinx_ept_egt_pilot.py --output specs/darwinx-ept-egt-pilot/results.json
python3 -m unittest tests/darwinx_ept_egt/test_pilot.py

Expected test result on 29 August 2026: three tests passed.

Evidence boundary

This package reproduces the deterministic mechanism pilot. It does not reproduce DarwinX, call a language model, train model weights, or establish that the simulated mutation landscape represents deployed AI systems.
