# Method Specification

The frozen hypotheses, constructs and acceptance criteria are in `product.md`.
The simulator, policies, metrics, evidence boundary and rerun command are in
`tech.md`. Forty paired seeds are used per landscape. Training capabilities
drive promotion; held-out capabilities never do. Protected capabilities and
compliance are non-compensable only in the multilevel arm. This asymmetry is
the intervention being tested, not an accidental implementation difference.

