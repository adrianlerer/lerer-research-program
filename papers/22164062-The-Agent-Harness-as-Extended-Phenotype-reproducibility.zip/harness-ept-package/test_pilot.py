import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "script" / "run_darwinx_ept_egt_pilot.py"
SPEC = importlib.util.spec_from_file_location("pilot", SCRIPT)
pilot = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = pilot
SPEC.loader.exec_module(pilot)


class PilotTests(unittest.TestCase):
    def test_reproducible(self):
        self.assertEqual(pilot.run(3), pilot.run(3))

    def test_same_candidate_count_for_all_policies(self):
        result = pilot.run(2)
        self.assertEqual(len(result["raw"]), 2 * 2 * 3)

    def test_ept_egt_never_accepts_protected_regression(self):
        result = pilot.run(10)
        rows = [r for r in result["raw"] if r["policy"] == "ept_egt_multilevel"]
        self.assertTrue(rows)
        self.assertTrue(all(r["protected_regressions"] == 0 for r in rows))
        self.assertTrue(all(r["compliance_failures_accepted"] == 0 for r in rows))


if __name__ == "__main__":
    unittest.main()
