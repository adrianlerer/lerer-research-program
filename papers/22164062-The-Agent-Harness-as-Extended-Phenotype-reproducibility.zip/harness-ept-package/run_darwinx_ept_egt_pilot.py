#!/usr/bin/env python3
"""Deterministic mechanism pilot for three harness-selection policies."""

from __future__ import annotations

import argparse
import json
import random
import statistics
from dataclasses import dataclass, replace
from pathlib import Path

VERTICALS = ("harness", "research", "security", "legal")
TRAIN = tuple(f"{v}:train:{i}" for v in VERTICALS for i in range(4))
HOLDOUT = tuple(f"{v}:holdout:{i}" for v in VERTICALS for i in range(2))
PROTECTED = tuple(f"{v}:protected" for v in VERTICALS)


@dataclass(frozen=True)
class Mutation:
    mid: str
    origin: str
    gains: dict[str, float]
    losses: dict[str, float]
    compliance_delta: float
    cost: int
    transferable: bool
    receiver_compatible: bool


@dataclass(frozen=True)
class State:
    values: dict[str, float]
    compliance: float = 1.0
    accepted: tuple[str, ...] = ()
    origins: tuple[str, ...] = ()
    cost: int = 0


def base_state() -> State:
    values = {key: 0.35 for key in TRAIN + HOLDOUT}
    values.update({key: 1.0 for key in PROTECTED})
    return State(values)


def make_mutations(seed: int, homogeneous: bool) -> list[Mutation]:
    rng = random.Random(seed)
    mutations: list[Mutation] = []
    for i in range(72):
        origin = VERTICALS[0] if homogeneous else rng.choice(VERTICALS)
        gains: dict[str, float] = {}
        losses: dict[str, float] = {}
        for _ in range(rng.randint(1, 3)):
            gains[f"{origin}:train:{rng.randrange(4)}"] = rng.uniform(0.12, 0.35)
        # Broad adaptations transfer to related unseen tasks, but only when a
        # receiver can safely adopt them.
        transferable = rng.random() < (0.18 if homogeneous else 0.48)
        compatible = rng.random() < 0.78
        if transferable:
            targets = [origin] if homogeneous else rng.sample(list(VERTICALS), rng.randint(1, 3))
            for target in targets:
                gains[f"{target}:holdout:{rng.randrange(2)}"] = rng.uniform(0.08, 0.28)
        if rng.random() < 0.34:
            harmed = rng.choice(VERTICALS)
            losses[f"{harmed}:train:{rng.randrange(4)}"] = rng.uniform(0.08, 0.30)
        if rng.random() < 0.20:
            losses[f"{rng.choice(VERTICALS)}:protected"] = rng.uniform(0.08, 0.30)
        mutations.append(
            Mutation(
                mid=f"s{seed}-m{i}",
                origin=origin,
                gains=gains,
                losses=losses,
                compliance_delta=-rng.uniform(0.08, 0.24) if rng.random() < 0.15 else 0.0,
                cost=rng.randint(1, 4),
                transferable=transferable,
                receiver_compatible=compatible,
            )
        )
    return mutations


def apply(state: State, mutation: Mutation, governed_transfer: bool) -> State:
    values = dict(state.values)
    for key, delta in mutation.gains.items():
        if ":holdout:" in key and governed_transfer and (
            not mutation.transferable or not mutation.receiver_compatible
        ):
            continue
        values[key] = min(1.0, values[key] + delta)
    for key, delta in mutation.losses.items():
        values[key] = max(0.0, values[key] - delta)
    return State(
        values=values,
        compliance=max(0.0, state.compliance + mutation.compliance_delta),
        accepted=state.accepted + (mutation.mid,),
        origins=state.origins + (mutation.origin,),
        cost=state.cost + mutation.cost,
    )


def merge(left: State, right: State) -> State:
    """Recombine complementary observable capabilities conservatively."""
    values = {key: max(left.values[key], right.values[key]) for key in left.values}
    accepted = tuple(dict.fromkeys(left.accepted + right.accepted))
    origins = tuple(dict.fromkeys(left.origins + right.origins))
    return State(
        values=values,
        compliance=min(left.compliance, right.compliance),
        accepted=accepted,
        origins=origins,
        cost=left.cost + right.cost,
    )


def coverage(state: State, keys: tuple[str, ...]) -> float:
    return sum(state.values[k] >= 0.60 for k in keys) / len(keys)


def train_score(state: State) -> float:
    return sum(state.values[k] for k in TRAIN)


def protected_regressions(state: State) -> int:
    return sum(state.values[k] < 0.90 for k in PROTECTED)


def valid(state: State) -> bool:
    return state.compliance >= 0.75 and protected_regressions(state) == 0


def single_lineage(mutations: list[Mutation]) -> State:
    state = base_state()
    for mutation in mutations:
        child = apply(state, mutation, governed_transfer=False)
        if train_score(child) > train_score(state):
            state = child
    return replace(state, cost=sum(m.cost for m in mutations))


def population(mutations: list[Mutation]) -> State:
    root = base_state()
    archive = [root]
    for mutation in mutations:
        parent = max(archive, key=train_score)
        child = apply(parent, mutation, governed_transfer=False)
        regression = sum(max(0.0, parent.values[k] - child.values[k]) for k in TRAIN)
        if train_score(child) > train_score(parent) and regression <= 0.35:
            archive.append(child)
        if len(archive) > 16:
            archive = sorted(archive, key=train_score, reverse=True)[:16]
    # Cross-lineage recombination is evaluated after mutation search. The
    # selector may inherit the union of complementary observed capabilities.
    recombinations = [merge(a, b) for index, a in enumerate(archive) for b in archive[index + 1 :]]
    winner = max(archive + recombinations, key=train_score)
    evaluation_work = sum(m.cost for m in mutations) + len(recombinations)
    return replace(winner, cost=evaluation_work)


def ecosystem_score(state: State) -> float:
    vertical_coverage = []
    for vertical in VERTICALS:
        keys = tuple(k for k in TRAIN if k.startswith(vertical + ":"))
        vertical_coverage.append(coverage(state, keys))
    diversity = len(set(state.origins)) / len(VERTICALS)
    balance = min(vertical_coverage)
    return train_score(state) + 1.5 * balance + 0.5 * diversity


def ept_egt_multilevel(mutations: list[Mutation]) -> State:
    root = base_state()
    archive = [root]
    best_by_vertical = {vertical: root for vertical in VERTICALS}
    for mutation in mutations:
        candidates = [best_by_vertical[mutation.origin], max(archive, key=ecosystem_score)]
        for parent in candidates:
            child = apply(parent, mutation, governed_transfer=True)
            individual_gain = train_score(child) > train_score(parent)
            vertical_keys = tuple(k for k in TRAIN if k.startswith(mutation.origin + ":"))
            vertical_gain = coverage(child, vertical_keys) >= coverage(parent, vertical_keys)
            if individual_gain and vertical_gain and valid(child):
                archive.append(child)
                if ecosystem_score(child) > ecosystem_score(best_by_vertical[mutation.origin]):
                    best_by_vertical[mutation.origin] = child
        if len(archive) > 24:
            archive = sorted(archive, key=ecosystem_score, reverse=True)[:24]
    inherited = root
    merge_evaluations = 0
    for specialist in best_by_vertical.values():
        candidate = merge(inherited, specialist)
        merge_evaluations += 1
        if valid(candidate) and ecosystem_score(candidate) >= ecosystem_score(inherited):
            inherited = candidate
    winner = max(archive + [inherited], key=ecosystem_score)
    evaluation_work = 2 * sum(m.cost for m in mutations) + merge_evaluations
    return replace(winner, cost=evaluation_work)


def summarize(state: State) -> dict[str, float | int]:
    return {
        "training_coverage": coverage(state, TRAIN),
        "heldout_coverage": coverage(state, HOLDOUT),
        "protected_regressions": protected_regressions(state),
        "compliance_failures_accepted": int(state.compliance < 0.75),
        "lineage_diversity": len(set(state.origins)),
        "accepted_mutations": len(state.accepted),
        "evaluation_cost": state.cost,
    }


def run(seeds: int = 40) -> dict:
    raw = []
    policies = {
        "single_lineage": single_lineage,
        "population": population,
        "ept_egt_multilevel": ept_egt_multilevel,
    }
    for landscape in ("heterogeneous", "homogeneous"):
        for seed in range(seeds):
            mutations = make_mutations(seed, homogeneous=landscape == "homogeneous")
            for name, policy in policies.items():
                raw.append({"landscape": landscape, "seed": seed, "policy": name, **summarize(policy(mutations))})
    aggregates = []
    for landscape in ("heterogeneous", "homogeneous"):
        for name in policies:
            rows = [r for r in raw if r["landscape"] == landscape and r["policy"] == name]
            aggregates.append({
                "landscape": landscape,
                "policy": name,
                **{key: statistics.mean(float(r[key]) for r in rows) for key in (
                    "training_coverage", "heldout_coverage", "protected_regressions",
                    "compliance_failures_accepted", "lineage_diversity", "accepted_mutations",
                    "evaluation_cost")},
            })
    return {
        "status": "MECHANISM_PILOT_ONLY",
        "seeds": seeds,
        "hypotheses_frozen_in": "specs/darwinx-ept-egt-pilot/product.md",
        "aggregates": aggregates,
        "raw": raw,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seeds", type=int, default=40)
    args = parser.parse_args()
    result = run(args.seeds)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["aggregates"], indent=2))


if __name__ == "__main__":
    main()
