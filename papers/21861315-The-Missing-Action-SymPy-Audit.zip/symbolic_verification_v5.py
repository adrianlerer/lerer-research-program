#!/usr/bin/env python3
"""Executable symbolic and numerical audit for The Missing Action v5.

The script uses the mathematical-connection convention D = d + A and
F = dA + A wedge A used in the manuscript. It separately checks the equivalent
physics convention D = partial + i g A and
F = dA + i g [A, A].
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp


OUT = Path(__file__).resolve().parent
REPORT = OUT / "symbolic_verification_v5_results.json"


def zero_matrix(expr: sp.Matrix) -> bool:
    return all(sp.simplify(x) == 0 for x in expr)


def matrix_strings(expr: sp.Matrix) -> list[str]:
    return [sp.sstr(sp.simplify(x)) for x in expr]


results: dict[str, dict] = {}


def record(eq: str, confirmed: bool, residual, scope: str) -> None:
    if isinstance(residual, sp.MatrixBase):
        rendered = matrix_strings(sp.Matrix(residual))
    elif isinstance(residual, (list, tuple)):
        rendered = [sp.sstr(sp.simplify(x)) for x in residual]
    else:
        rendered = sp.sstr(sp.simplify(residual))
    results[eq] = {
        "status": "CONFIRMADA" if confirmed else "NO CONFIRMADA",
        "residual": rendered,
        "scope": scope,
    }


# ---------------------------------------------------------------------------
# Equations (14), (19): generic two-coordinate metric EL + Rayleigh residual.
# ---------------------------------------------------------------------------
t = sp.symbols("t", real=True)
q = [sp.Function("q1")(t), sp.Function("q2")(t)]
qd = [sp.diff(x, t) for x in q]
qdd = [sp.diff(x, t, 2) for x in q]
g11 = sp.Function("g11")(*q, t)
g12 = sp.Function("g12")(*q, t)
g22 = sp.Function("g22")(*q, t)
gmat = sp.Matrix([[g11, g12], [g12, g22]])
V = sp.Function("V")(*q, t)
U_h = sp.Function("U_h")(*q, t)
C11 = sp.Function("C11")(*q, t)
C12 = sp.Function("C12")(*q, t)
C22 = sp.Function("C22")(*q, t)
Cmat = sp.Matrix([[C11, C12], [C12, C22]])
qd_vec = sp.Matrix(qd)
L_metric = sp.Rational(1, 2) * (qd_vec.T * gmat * qd_vec)[0] - V - U_h
R_q = sp.Rational(1, 2) * (qd_vec.T * Cmat * qd_vec)[0]

el_metric = []
expected_metric = []
el_damped = []
for a in range(2):
    e_cons = sp.diff(sp.diff(L_metric, qd[a]), t) - sp.diff(L_metric, q[a])
    e_damp = e_cons + sp.diff(R_q, qd[a])
    el_metric.append(sp.expand(e_cons))
    el_damped.append(sp.expand(e_damp))

    expected = sum(gmat[a, b] * qdd[b] for b in range(2))
    expected += sum(sp.diff(gmat[a, b], t, evaluate=False) * 0 for b in range(2))
    # Explicit partial_t derivative: replace q(t) by independent symbols first.
    x1, x2, tau = sp.symbols("x1 x2 tau", real=True)
    for b in range(2):
        independent_metric = gmat[a, b].func(x1, x2, tau)
        explicit_t = sp.Subs(
            sp.diff(independent_metric, tau),
            (x1, x2, tau),
            (q[0], q[1], t),
        )
        expected += explicit_t * qd[b]
    for b in range(2):
        for c in range(2):
            gamma_first = sp.Rational(1, 2) * (
                sp.diff(gmat[a, c], q[b])
                + sp.diff(gmat[a, b], q[c])
                - sp.diff(gmat[b, c], q[a])
            )
            expected += gamma_first * qd[b] * qd[c]
    expected += sp.diff(V + U_h, q[a])
    expected_metric.append(sp.expand(expected))

metric_residual = sp.Matrix(
    [sp.simplify(el_metric[a] - expected_metric[a]) for a in range(2)]
)
record("14_metric", zero_matrix(metric_residual), metric_residual, "generic symmetric 2x2 metric")

rayleigh_force = Cmat * qd_vec
eq19_residual = sp.Matrix(
    [sp.simplify(el_damped[a] - expected_metric[a] - rayleigh_force[a]) for a in range(2)]
)
record("19", zero_matrix(eq19_residual), eq19_residual, "generic symmetric 2x2 Gamma")


# ---------------------------------------------------------------------------
# Equations (14a), (14b): non-Abelian SO(3) matrix specialization, exact.
# ---------------------------------------------------------------------------
T1 = sp.Matrix([[0, 0, 0], [0, 0, -1], [0, 1, 0]])
T2 = sp.Matrix([[0, 0, 1], [0, 0, 0], [-1, 0, 0]])
T3 = sp.Matrix([[0, -1, 0], [1, 0, 0], [0, 0, 0]])

Q1, Q2, T = sp.symbols("Q1 Q2 T", real=True)
A0_base = (Q1 + T) * T1 + Q2 * T2
A1_base = Q2 * T1 + T * T2 + Q1 * T3
A2_base = T * T1 + Q1 * T2 + Q2 * T3
bases = [A0_base, A1_base, A2_base]
subs_path = {Q1: q[0], Q2: q[1], T: t}
A0, A1, A2 = [a.xreplace(subs_path) for a in bases]
As = [A1, A2]
B = A0 + qd[0] * A1 + qd[1] * A2
P = sp.Matrix([sp.Function(f"p{i}")(t) for i in range(3)])
W = sp.Matrix([sp.Function(f"w{i}")(t) for i in range(3)])
Pdot_on_shell = W - B * P
Wdot_on_shell = -B * W
on_shell = {
    **{sp.diff(P[i], t): Pdot_on_shell[i] for i in range(3)},
    **{sp.diff(W[i], t): Wdot_on_shell[i] for i in range(3)},
}

gauge_differences = []
for mu in range(2):
    partial_mu_A0 = sp.diff(bases[0], [Q1, Q2][mu]).xreplace(subs_path)
    partial_mu_A = [
        sp.diff(bases[alpha + 1], [Q1, Q2][mu]).xreplace(subs_path)
        for alpha in range(2)
    ]
    first = partial_mu_A0 + sum(
        (qd[alpha] * partial_mu_A[alpha] for alpha in range(2)), sp.zeros(3)
    )
    q14a = (W.T * first * P)[0] - sp.diff((W.T * As[mu] * P)[0], t)
    q14a = sp.expand(q14a.xreplace(on_shell).subs(on_shell))

    partial_t_Amu = sp.diff(bases[mu + 1], T).xreplace(subs_path)
    Fmut = partial_mu_A0 - partial_t_Amu + As[mu] * A0 - A0 * As[mu]
    spatial_sum = sp.zeros(3)
    for alpha in range(2):
        partial_mu_Aalpha = sp.diff(
            bases[alpha + 1], [Q1, Q2][mu]
        ).xreplace(subs_path)
        partial_alpha_Amu = sp.diff(
            bases[mu + 1], [Q1, Q2][alpha]
        ).xreplace(subs_path)
        Fmua = (
            partial_mu_Aalpha
            - partial_alpha_Amu
            + As[mu] * As[alpha]
            - As[alpha] * As[mu]
        )
        spatial_sum += qd[alpha] * Fmua
    q14b = (W.T * (Fmut + spatial_sum) * P)[0]
    gauge_differences.append(sp.simplify(sp.expand(q14a - q14b)))

gauge_pair_confirmed = all(x == 0 for x in gauge_differences)
record(
    "14a",
    gauge_pair_confirmed,
    gauge_differences,
    "direct variation and exact non-Abelian SO(3) specialization with D_tW=0",
)
record(
    "14b",
    gauge_pair_confirmed,
    gauge_differences,
    "14a minus mixed-curvature form in exact non-Abelian SO(3) specialization",
)


# ---------------------------------------------------------------------------
# Equation (16): vector EL equation for skew connection B(t).
# ---------------------------------------------------------------------------
b = sp.Function("b")(t)
B1 = b * T1
Pv = sp.Matrix([sp.Function(f"P{i}")(t) for i in range(3)])
Wv = sp.diff(Pv, t) + B1 * Pv
L_prior = sp.Rational(1, 2) * (Wv.T * Wv)[0]
el_p = sp.Matrix(
    [sp.diff(sp.diff(L_prior, sp.diff(Pv[i], t)), t) - sp.diff(L_prior, Pv[i]) for i in range(3)]
)
expected_p = sp.diff(Wv, t) + B1 * Wv
eq16_residual = sp.simplify(el_p - expected_p)
record("16", zero_matrix(eq16_residual), eq16_residual, "generic b(t), skew SO(3) generator")


# ---------------------------------------------------------------------------
# Equation (17): exact constant-connection test; generic path ordering is not
# represented by SymPy and therefore does not receive a general confirmation.
# ---------------------------------------------------------------------------
b0 = sp.symbols("b0", real=True)
B0 = b0 * T1
p0 = sp.Matrix(sp.symbols("p0:3", real=True))
P_const = sp.exp(-t * B0) * p0
eq17_constant_residual = sp.simplify(sp.diff(P_const, t) + B0 * P_const)
results["17"] = {
    "status": "NO CONFIRMADA",
    "residual": {
        "constant_connection_residual": matrix_strings(eq17_constant_residual),
        "generic_unresolved_object": "PathOrder[exp(-Integral(A_A dx^A))] is not represented by SymPy's ordinary Matrix.exp",
    },
    "scope": "constant connection reduces to zero; generic path-ordered transport remains outside this symbolic proof",
}


# ---------------------------------------------------------------------------
# Equation (20): internal residue dynamics.
# ---------------------------------------------------------------------------
h = sp.Function("h")(t)
eta_h, xi_h, k_h = sp.symbols("eta_h xi_h k_h", positive=True)
r_h = sp.Function("r_h")(t)
L_h = eta_h * sp.diff(h, t) ** 2 / 2 - k_h * h**2 / 2 + h * r_h
R_h = xi_h * sp.diff(h, t) ** 2 / 2
el_h = sp.diff(sp.diff(L_h, sp.diff(h, t)), t) - sp.diff(L_h, h) + sp.diff(R_h, sp.diff(h, t))
expected_h = eta_h * sp.diff(h, t, 2) + xi_h * sp.diff(h, t) + k_h * h - r_h
eq20_residual = sp.simplify(el_h - expected_h)
record("20", eq20_residual == 0, eq20_residual, "generic scalar residue coordinate")


# ---------------------------------------------------------------------------
# Equations (21), (22): matrix algebra in the overdamped and factorized cases.
# ---------------------------------------------------------------------------
c11, c12, c22 = sp.symbols("c11 c12 c22", real=True)
Gamma_generic = sp.Matrix([[c11, c12], [c12, c22]])
drive = sp.symbols("drive", real=True)
dpsi = sp.Matrix(sp.symbols("psi1 psi2", real=True))
qdot21 = drive * Gamma_generic.inv() * dpsi
eq21_residual = sp.simplify(Gamma_generic * qdot21 - drive * dpsi)
record("21", zero_matrix(eq21_residual), eq21_residual, "invertible generic symmetric 2x2 Gamma")

cli, ihr, rho_drive, tci, mf = sp.symbols("CLI IHR rho TCI MF", nonzero=True)
cb11, cb12, cb22 = sp.symbols("cb11 cb12 cb22", real=True)
H_factor = sp.Matrix([[cb11, cb12], [cb12, cb22]])
Phi = tci * mf / (cli * ihr)
qdot_from_21 = rho_drive * tci * mf * (cli * ihr * H_factor).inv() * dpsi
qdot_22 = rho_drive * Phi * H_factor.inv() * dpsi
eq22_residual = sp.simplify(qdot_from_21 - qdot_22)
record("22", zero_matrix(eq22_residual), eq22_residual, "calibrated Gamma = CLI IHR H")


# ---------------------------------------------------------------------------
# Constitutive Gamma(varrho,d,q) = eta(varrho) chi(d) H(q), PSD proof.
# H is parameterized as B.T B, so positivity is imposed rather than assumed.
# ---------------------------------------------------------------------------
eta_r, chi_d = sp.symbols("eta_varrho chi_d", nonnegative=True)
a_h, b_h, c_h, v1, v2 = sp.symbols("a_h b_h c_h v1 v2", real=True)
B_h = sp.Matrix([[a_h, b_h], [0, c_h]])
H = B_h.T * B_h
Gamma = eta_r * chi_d * H
gamma_symmetry = sp.simplify(Gamma - Gamma.T)
power = sp.factor((sp.Matrix([v1, v2]).T * Gamma * sp.Matrix([v1, v2]))[0])
power_sos = sp.expand(eta_r * chi_d * ((a_h * v1 + b_h * v2) ** 2 + (c_h * v2) ** 2))
psd_residual = sp.simplify(power - power_sos)

rng = np.random.default_rng(20260809)
min_power = np.inf
for _ in range(5000):
    aa, bb, cc = rng.normal(size=3)
    er, cd = rng.uniform(0.0, 5.0, size=2)
    vv = rng.normal(size=2)
    Bn = np.array([[aa, bb], [0.0, cc]])
    Gn = er * cd * (Bn.T @ Bn)
    min_power = min(min_power, float(vv @ Gn @ vv))

record("Gamma_symmetry", zero_matrix(gamma_symmetry), gamma_symmetry, "H = B.T B")
record(
    "Gamma_PSD",
    psd_residual == 0 and min_power >= -1e-12,
    [psd_residual, sp.Symbol(f"numeric_min_power={min_power:.6e}")],
    "sum-of-squares proof plus 5000 admissible numerical draws",
)


# ---------------------------------------------------------------------------
# Physics convention: D_mu = partial_mu + i g A_mu and
# F_mu nu = partial_mu A_nu - partial_nu A_mu + i g[A_mu,A_nu].
# ---------------------------------------------------------------------------
x0, x1, gc = sp.symbols("x0 x1 g", real=True)
I = sp.I
sigma1 = sp.Matrix([[0, 1], [1, 0]]) / 2
sigma2 = sp.Matrix([[0, -I], [I, 0]]) / 2
sigma3 = sp.Matrix([[1, 0], [0, -1]]) / 2
Aphys0 = x1 * sigma1 + x0 * sigma2
Aphys1 = x0 * sigma3 + x1 * sigma2
psi = sp.Matrix([x0**2 + x1, x0 * x1 + 1])


def D(mu: int, field: sp.Matrix, A_mu: sp.Matrix) -> sp.Matrix:
    var = [x0, x1][mu]
    return field.diff(var) + I * gc * A_mu * field


F01 = Aphys1.diff(x0) - Aphys0.diff(x1) + I * gc * (Aphys0 * Aphys1 - Aphys1 * Aphys0)
comm_D = D(0, D(1, psi, Aphys1), Aphys0) - D(1, D(0, psi, Aphys0), Aphys1)
gauge_comm_residual = sp.simplify(comm_D - I * gc * F01 * psi)
record(
    "gauge_commutator",
    zero_matrix(gauge_comm_residual),
    gauge_comm_residual,
    "SU(2), D=partial+i g A, F=dA+i g[A,A]",
)


# Infinitesimal gauge covariance to first order in s.
s = sp.symbols("s", real=True)
eps = (x0 + x1) * sigma1 + x0 * sigma3
Uinf = sp.eye(2) + I * gc * s * eps
Uinv_inf = sp.eye(2) - I * gc * s * eps


def transformed_A(A_mu: sp.Matrix, var: sp.Symbol) -> sp.Matrix:
    # A' = U A U^-1 + (1/(i g)) U partial_mu U^-1, retained to O(s).
    raw = Uinf * A_mu * Uinv_inf + (Uinf * Uinv_inf.diff(var)) / (I * gc)
    return raw.applyfunc(lambda z: sp.diff(z, s).subs(s, 0) * s + z.subs(s, 0))


A0p = transformed_A(Aphys0, x0)
A1p = transformed_A(Aphys1, x1)
psip = Uinf * psi
cov_res = D(0, psip, A0p) - Uinf * D(0, psi, Aphys0)
cov_linear = cov_res.applyfunc(lambda z: sp.simplify(sp.diff(z, s).subs(s, 0)))
record(
    "infinitesimal_gauge_covariance",
    zero_matrix(cov_linear),
    cov_linear,
    "coefficient of infinitesimal parameter s for SU(2) matter derivative",
)

F01p = A1p.diff(x0) - A0p.diff(x1) + I * gc * (A0p * A1p - A1p * A0p)
curv_cov = F01p - Uinf * F01 * Uinv_inf
curv_linear = curv_cov.applyfunc(lambda z: sp.simplify(sp.diff(z, s).subs(s, 0)))
record(
    "curvature_covariance",
    zero_matrix(curv_linear),
    curv_linear,
    "coefficient of infinitesimal parameter s for F'=UFU^-1",
)


# ---------------------------------------------------------------------------
# Numerical ODE: admissible Gamma, positive dissipated power, energy decay.
# ---------------------------------------------------------------------------
Gamma_num = np.array([[1.6, 0.4], [0.4, 1.1]])
K_num = np.array([[1.2, 0.2], [0.2, 0.9]])


def rhs(_t: float, y: np.ndarray) -> np.ndarray:
    qn = y[:2]
    vn = y[2:]
    return np.concatenate([vn, -Gamma_num @ vn - K_num @ qn])


sol = solve_ivp(rhs, (0.0, 20.0), np.array([1.0, -0.5, 0.2, 0.7]), rtol=1e-10, atol=1e-12, dense_output=False)
powers = np.array([v @ Gamma_num @ v for v in sol.y[2:].T])
energies = np.array([
    0.5 * (v @ v) + 0.5 * (qq @ K_num @ qq)
    for qq, v in zip(sol.y[:2].T, sol.y[2:].T)
])
energy_increases = int(np.sum(np.diff(energies) > 1e-8))
results["numerical_ode"] = {
    "status": "CONFIRMADA" if powers.min() >= -1e-12 and energy_increases == 0 else "NO CONFIRMADA",
    "residual": {
        "min_dissipated_power": float(powers.min()),
        "max_dissipated_power": float(powers.max()),
        "initial_energy": float(energies[0]),
        "final_energy": float(energies[-1]),
        "energy_increase_steps": energy_increases,
        "steps": int(sol.t.size),
    },
    "scope": "2D damped trajectory with admissible SPD Gamma",
}

results["dimensional_analysis"] = {
    "status": "NO CONFIRMADA",
    "residual": "The source series does not define units for IusSpace coordinates, rho, eta(varrho), chi(d), H, or S.",
    "scope": "dimensional closure unavailable; sign of dissipated power was tested separately",
}

REPORT.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(results, indent=2, ensure_ascii=False))
